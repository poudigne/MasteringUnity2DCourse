These brushes were created in Photoshop CS2, and, as such, will not work in lower versions of Photoshop or other programs.

Included in the folders is an image pack for all of the brushes, so you can make brushes for any program you'd like. These brushes may be converted to any other brush-using program format and then posted to DeviantArt provided you link back to the original brush set, and send me the link to the new version. They must not contain different terms of use.

I will include links to any converted brushes in the artist comments to avoid overlapping conversions.

There is also a font included with most of the map legend icons, the cities, and the scrolls and compass, which means they will scale well, and work in any program you so desire to use to create a map. (I hope you like exploring, though, because they filled up the upper case, lower case, and all easily attainable symbols!)

These brushes may be used on DeviantArt, off DeviantArt, non-commercially, commerically, and in fact, for anything your heart may so desire. They are absolutely free. The only restriction is that you may not repost these brush sets anywhere else without my written consent.

http://calthyechild.deviantart.com