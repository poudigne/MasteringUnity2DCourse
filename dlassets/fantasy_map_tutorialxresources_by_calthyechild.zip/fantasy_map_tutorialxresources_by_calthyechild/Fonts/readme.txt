These fonts are free for whatever you feel like using them for, though likely as not that's pretty limited to fantasy maps.

You may not repost them on other sites, but you may use them both non-commercially and commercially, as well as on and off of DeviantArt at your will.

FantasyMap: This font was hand written by me based on the style of Tolkien's maps. It contains more special characters than you can sneeze at. Keeping in mind fantasy creators tend to use strange symbols, I made sure to include as many as I could!

It's a crappy font, but you get what you pay for, right?

MapIcons: This font contains most of the map icons in the brush set, only, fonts are pretty well universal so now you can use the brushes outside of Photoshop! While they aren't as pretty, due to being converted to black and white vector outlines, they are functional. You will have to explore your keyboard to find all of the symbols... I jammed them in wherever they would fit, with no rhyme or reason, onto pretty much every single readily accessable key on a standard keyboard. Uppercase letters, lowercase letters, numbers, symbols, punctuation... they're all map symbols in this font. It includes the scrolls and cities.